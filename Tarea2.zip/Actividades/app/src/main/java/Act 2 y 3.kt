import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PositionExercise()
        }
    }
}

@Composable
fun PositionExercise() {
    Column(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.weight(1f).height(50.dp).background(Color.Red)) {
                Text("Top Start", modifier = Modifier.align(Alignment.TopStart), color = Color.White)
            }
            Box(modifier = Modifier.weight(1f).height(50.dp).background(Color.Blue)) {
                Text("Top", modifier = Modifier.align(Alignment.Center), color = Color.White)
            }
            Box(modifier = Modifier.weight(1f).height(50.dp).background(Color.Magenta)) {
                Text("Top End", modifier = Modifier.align(Alignment.TopEnd), color = Color.White)
            }
        }

        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color.Green)) {
                Text("Center Start", modifier = Modifier.align(Alignment.CenterStart), color = Color.Black)
            }
            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color.Gray)) {
                Text("Center", modifier = Modifier.align(Alignment.Center), color = Color.Black)
            }
            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color.Black)) {
                Text("Center End", modifier = Modifier.align(Alignment.CenterEnd), color = Color.White)
            }
        }

        Row(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.weight(1f).height(50.dp).background(Color.Cyan)) {
                Text("Bottom Start", modifier = Modifier.align(Alignment.BottomStart), color = Color.Black)
            }
            Box(modifier = Modifier.weight(1f).height(50.dp).background(Color.DarkGray)) {
                Text("Bottom Center", modifier = Modifier.align(Alignment.BottomCenter), color = Color.White)
            }
            Box(modifier = Modifier.weight(1f).height(50.dp).background(Color.Yellow)) {
                Text("Bottom End", modifier = Modifier.align(Alignment.BottomEnd), color = Color.Black)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    PositionExercise()
}
