import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.ui.text.input.TextFieldValue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CalculatorApp()
        }
    }
}

@Composable
fun CalculatorApp() {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        CalculatorView()
        Spacer(modifier = Modifier.height(32.dp))
        MinMaxView()
    }
}

@Composable
fun CalculatorView() {
    var num1 by remember { mutableStateOf(TextFieldValue()) }
    var num2 by remember { mutableStateOf(TextFieldValue()) }
    var result by remember { mutableStateOf("") }

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(value = num1, onValueChange = { num1 = it }, label = { Text("Número 1") })
        OutlinedTextField(value = num2, onValueChange = { num2 = it }, label = { Text("Número 2") })

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { result = (num1.text.toDoubleOrNull() ?: 0.0 + num2.text.toDoubleOrNull() ?: 0.0).toString() }) {
            Text("Sumar")
        }

        OutlinedButton(onClick = { result = (num1.text.toDoubleOrNull() ?: 0.0 - num2.text.toDoubleOrNull() ?: 0.0).toString() }) {
            Text("Restar")
        }

        IconButton(onClick = { result = (num1.text.toDoubleOrNull() ?: 0.0 * num2.text.toDoubleOrNull() ?: 0.0).toString() }) {
            Icon(Icons.Filled.Calculate, contentDescription = "Multiplicar")
        }

        Image(
            painter = painterResource(id = android.R.drawable.ic_menu_gallery),
            contentDescription = "Dividir",
            modifier = Modifier.clickable {
                val divisor = num2.text.toDoubleOrNull() ?: 1.0
                result = if (divisor != 0.0) (num1.text.toDoubleOrNull() ?: 0.0 / divisor).toString() else "Error"
            }
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Resultado: $result", fontSize = 20.sp)
    }
}

@Composable
fun MinMaxView() {
    var num1 by remember { mutableStateOf(TextFieldValue()) }
    var num2 by remember { mutableStateOf(TextFieldValue()) }
    var num3 by remember { mutableStateOf(TextFieldValue()) }
    var maxMin by remember { mutableStateOf("Ingrese 3 números") }

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(value = num1, onValueChange = { num1 = it }, label = { Text("Número 1") })
        OutlinedTextField(value = num2, onValueChange = { num2 = it }, label = { Text("Número 2") })
        OutlinedTextField(value = num3, onValueChange = { num3 = it }, label = { Text("Número 3") })

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = {
            val numbers = listOfNotNull(
                num1.text.toDoubleOrNull(),
                num2.text.toDoubleOrNull(),
                num3.text.toDoubleOrNull()
            )
            if (numbers.size == 3) {
                maxMin = "Mayor: ${numbers.maxOrNull()} - Menor: ${numbers.minOrNull()}"
            } else {
                maxMin = "Ingrese valores válidos"
            }
        }) {
            Text("Calcular Mayor y Menor")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(text = maxMin, fontSize = 20.sp)
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    CalculatorApp()
}
